var structdn__api__set__comp__mode__t =
[
    [ "paramId", "structdn__api__set__comp__mode__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "compMode", "structdn__api__set__comp__mode__t.html#a328b17505e30df3cd4d9ef158fb279fc", null ]
];