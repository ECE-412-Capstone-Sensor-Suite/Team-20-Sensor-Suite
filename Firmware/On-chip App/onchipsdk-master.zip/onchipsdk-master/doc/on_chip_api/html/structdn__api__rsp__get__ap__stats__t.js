var structdn__api__rsp__get__ap__stats__t =
[
    [ "rc", "structdn__api__rsp__get__ap__stats__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__ap__stats__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "lastPO", "structdn__api__rsp__get__ap__stats__t.html#a98426225fca3fbd3ac0051af6df45fcf", null ],
    [ "lastPFE", "structdn__api__rsp__get__ap__stats__t.html#a82ca3d8e60b6ee5304b80078f8a4559f", null ],
    [ "numRxSetTimeErr", "structdn__api__rsp__get__ap__stats__t.html#ab7021c9f8e181c638a12d2e34d924678", null ],
    [ "numSignalErr", "structdn__api__rsp__get__ap__stats__t.html#aef6db2a3c53f5360af4ea0476e1d6543", null ],
    [ "state", "structdn__api__rsp__get__ap__stats__t.html#a098b904cc4606bc5d8dd934d4803a979", null ]
];