var structdn__api__rsp__get__time__t =
[
    [ "rc", "structdn__api__rsp__get__time__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__time__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "upTime", "structdn__api__rsp__get__time__t.html#acc0995851723a415a458a645ce8f8cd6", null ],
    [ "utcTime", "structdn__api__rsp__get__time__t.html#acd254388f0d24657fe9923631c3e1910", null ],
    [ "asn", "structdn__api__rsp__get__time__t.html#ae70ca2c09de421fceb9e482aa2fe5c50", null ],
    [ "offset", "structdn__api__rsp__get__time__t.html#a9851db06897094b16c2046f53139fda5", null ]
];