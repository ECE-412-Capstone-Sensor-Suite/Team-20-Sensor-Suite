var structdn__api__loc__notif__events__t =
[
    [ "events", "structdn__api__loc__notif__events__t.html#ad29858f6d8ab73f2970f41cb21a76b84", null ],
    [ "state", "structdn__api__loc__notif__events__t.html#adc6e5733fc3c22f0a7b2914188c49c90", null ],
    [ "alarms", "structdn__api__loc__notif__events__t.html#aac467fbf7938baf5606e3926d069639d", null ]
];