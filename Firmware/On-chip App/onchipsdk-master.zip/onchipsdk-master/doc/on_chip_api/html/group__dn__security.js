var group__dn__security =
[
    [ "dn_sec_ccmopt_t", "structdn__sec__ccmopt__t.html", [
      [ "M", "structdn__sec__ccmopt__t.html#a008459d76559f880b7efce6733228536", null ],
      [ "L", "structdn__sec__ccmopt__t.html#a25573fa95fbf454e74acd23fbe693657", null ]
    ] ],
    [ "dn_sec_ccm_auth_context_t", "structdn__sec__ccm__auth__context__t.html", [
      [ "micBuf", "structdn__sec__ccm__auth__context__t.html#a0dc064a64c77205c2d3d833da1eb0e4e", null ],
      [ "keyBuf", "structdn__sec__ccm__auth__context__t.html#acf339828baf76a47da1f3a3588b0e799", null ],
      [ "nonceBuf", "structdn__sec__ccm__auth__context__t.html#a93e5dfe72b7c103258db4b9372f7756c", null ],
      [ "authLen", "structdn__sec__ccm__auth__context__t.html#ad89dc9dce33a44e00870df39df20961f", null ],
      [ "fFirstOpDone", "structdn__sec__ccm__auth__context__t.html#a313bf9237c4adb6d3cdd134b1ac635dd", null ]
    ] ],
    [ "DN_AES_BLOCKSIZE", "group__dn__security.html#ga887a059cab16255a044ae717a38a20d5", null ],
    [ "DN_NONCE_LEN", "group__dn__security.html#gae7ee278c6a9aac1c6b836c50d2c120ff", null ],
    [ "dn_sec_aesCbcMac", "group__dn__security.html#ga60e16f84c1be8065b1ca2b237688bb68", null ],
    [ "dn_sec_aesCtr", "group__dn__security.html#ga233fa4f822f4ce51e734676a332cdc75", null ],
    [ "dn_sec_aesCcmEncrypt", "group__dn__security.html#ga7298404055a84a8ffa35497f64110020", null ],
    [ "dn_sec_aesCcmDecrypt", "group__dn__security.html#gaf130f5a3c71d9ff925c3de56ff40ecaa", null ],
    [ "dn_sec_ccmInitAuthContext", "group__dn__security.html#ga91b057192c9e18d831b0c8c4c520c256", null ],
    [ "dn_sec_ccmAuth", "group__dn__security.html#ga1a95617b21079de3fcab9b2da8fe2c8d", null ],
    [ "dn_sec_ccmCtrMic", "group__dn__security.html#ga9d963fc22dd277be5315554d2f53a764", null ]
];