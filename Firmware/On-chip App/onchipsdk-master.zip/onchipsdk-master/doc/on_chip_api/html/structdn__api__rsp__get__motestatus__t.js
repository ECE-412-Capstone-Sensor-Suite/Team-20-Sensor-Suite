var structdn__api__rsp__get__motestatus__t =
[
    [ "rc", "structdn__api__rsp__get__motestatus__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__motestatus__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "state", "structdn__api__rsp__get__motestatus__t.html#adc6e5733fc3c22f0a7b2914188c49c90", null ],
    [ "stateReason", "structdn__api__rsp__get__motestatus__t.html#a346a7502444719e4f5a11a61dc15af3f", null ],
    [ "reserved_1", "structdn__api__rsp__get__motestatus__t.html#a094fa3ab88fc174fbd791e3e51805316", null ],
    [ "numParents", "structdn__api__rsp__get__motestatus__t.html#a0b3caaaafd96a94e86fc7626546cbbb6", null ],
    [ "alarms", "structdn__api__rsp__get__motestatus__t.html#a1aed2f2af8155d5e04ddeef8be70c7ea", null ],
    [ "reserved_2", "structdn__api__rsp__get__motestatus__t.html#aa87a016bdf61ef2118347523cc086c80", null ]
];