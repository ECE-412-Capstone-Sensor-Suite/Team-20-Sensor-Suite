var group___stack =
[
    [ "Local Interface Module", "group__module__dnm__local.html", "group__module__dnm__local" ],
    [ "Raw Local Interface", "group__loc__intf.html", "group__loc__intf" ]
];