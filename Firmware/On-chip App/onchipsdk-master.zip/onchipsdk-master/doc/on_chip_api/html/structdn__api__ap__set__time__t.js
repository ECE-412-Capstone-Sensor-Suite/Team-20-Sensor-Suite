var structdn__api__ap__set__time__t =
[
    [ "paramId", "structdn__api__ap__set__time__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "seqNum", "structdn__api__ap__set__time__t.html#ac946a1bca79e072cec9bc01cb0c827c2", null ],
    [ "utcTime", "structdn__api__ap__set__time__t.html#acd254388f0d24657fe9923631c3e1910", null ],
    [ "uartTstamp", "structdn__api__ap__set__time__t.html#a7a5994af009adce03861672aed25e042", null ]
];