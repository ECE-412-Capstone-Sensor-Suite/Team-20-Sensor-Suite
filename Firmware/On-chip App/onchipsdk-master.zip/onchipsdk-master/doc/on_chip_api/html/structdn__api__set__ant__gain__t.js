var structdn__api__set__ant__gain__t =
[
    [ "paramId", "structdn__api__set__ant__gain__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "antGain", "structdn__api__set__ant__gain__t.html#aab1bb021887cb621effce620b6ca35b7", null ]
];