var structdn__api__rsp__get__sizeinfoext__t =
[
    [ "rc", "structdn__api__rsp__get__sizeinfoext__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__sizeinfoext__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "maxFrames", "structdn__api__rsp__get__sizeinfoext__t.html#a382692c69007467ba01583eda5f29af7", null ],
    [ "maxLinks", "structdn__api__rsp__get__sizeinfoext__t.html#ad5f320ae044a401fd698391cbf71c2cf", null ],
    [ "maxNbrs", "structdn__api__rsp__get__sizeinfoext__t.html#aed49feb25ef52aea37555a26e73e37c6", null ],
    [ "maxRoutes", "structdn__api__rsp__get__sizeinfoext__t.html#a0603e151bbe2860fa87b072976314adf", null ],
    [ "maxGraphs", "structdn__api__rsp__get__sizeinfoext__t.html#aa6607c9c7429d7847658896287f4dcc8", null ],
    [ "maxQSize", "structdn__api__rsp__get__sizeinfoext__t.html#a38d5655d5daf4ce95b0430f671fac20a", null ]
];