var group__device__other =
[
    [ "CLI", "group__device__cli.html", "group__device__cli" ],
    [ "UART", "group__device__uart.html", "group__device__uart" ],
    [ "flashinfo", "group__device__flashinfo.html", "group__device__flashinfo" ],
    [ "random", "group__device__rand.html", null ]
];