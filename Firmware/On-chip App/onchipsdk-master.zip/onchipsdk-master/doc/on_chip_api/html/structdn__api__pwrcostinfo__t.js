var structdn__api__pwrcostinfo__t =
[
    [ "maxTxCost", "structdn__api__pwrcostinfo__t.html#a58e806ddc434f4e50103da94e2ae06d4", null ],
    [ "maxRxCost", "structdn__api__pwrcostinfo__t.html#aadf48a3ff6318b73f027742633061bc1", null ],
    [ "minTxCost", "structdn__api__pwrcostinfo__t.html#ae0159519d7ab542586cd4b872fc14b30", null ],
    [ "minRxCost", "structdn__api__pwrcostinfo__t.html#a7dff43ba9223cdc1dd7b3812c78551bf", null ]
];