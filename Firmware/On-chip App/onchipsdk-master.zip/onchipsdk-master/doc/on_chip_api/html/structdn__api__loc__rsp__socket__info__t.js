var structdn__api__loc__rsp__socket__info__t =
[
    [ "rc", "structdn__api__loc__rsp__socket__info__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "index", "structdn__api__loc__rsp__socket__info__t.html#a3bda97eaa781a79b23cdfe9a63841b51", null ],
    [ "socketId", "structdn__api__loc__rsp__socket__info__t.html#a13a24911b35c9f0cf779764a55faabc9", null ],
    [ "protocol", "structdn__api__loc__rsp__socket__info__t.html#aa55cc1e34e5f2ddb8b0f98d89af60957", null ],
    [ "bindState", "structdn__api__loc__rsp__socket__info__t.html#a28e3d9cf5b701578a47f77bd0cef0287", null ],
    [ "port", "structdn__api__loc__rsp__socket__info__t.html#afbb6b3545f891423a28757d914e53aad", null ]
];