var group__device__battery =
[
    [ "dn_adc_load_t", "group__device__battery.html#ga81d330dd3f088af31efa47da73044ffd", [
      [ "DN_ADC_LOAD_BATT_NONE", "group__device__battery.html#gga81d330dd3f088af31efa47da73044ffda3180d20460431880086cb7e90bb1c161", null ],
      [ "DN_ADC_LOAD_BATT_100_OHM", "group__device__battery.html#gga81d330dd3f088af31efa47da73044ffda1b8a46732cd2f6bc09a0b48e6d7f1a0f", null ],
      [ "DN_ADC_LOAD_BATT_500_OHM", "group__device__battery.html#gga81d330dd3f088af31efa47da73044ffda903c75ab6202cb35604db2d72b2f62f5", null ],
      [ "DN_ADC_LOAD_BATT_83_OHM", "group__device__battery.html#gga81d330dd3f088af31efa47da73044ffda00313eeb0a5d608294a094c5db155124", null ]
    ] ]
];