var structdn__api__loc__notif__received__t =
[
    [ "socketId", "structdn__api__loc__notif__received__t.html#a13a24911b35c9f0cf779764a55faabc9", null ],
    [ "sourceAddr", "structdn__api__loc__notif__received__t.html#adde42674b05c4300f4f47e5ad9095f4a", null ],
    [ "sourcePort", "structdn__api__loc__notif__received__t.html#a10d6cba85865b1e21bfe978c20b742d3", null ],
    [ "data", "structdn__api__loc__notif__received__t.html#a1d8638f8ade729d19099dc7a223302bd", null ]
];