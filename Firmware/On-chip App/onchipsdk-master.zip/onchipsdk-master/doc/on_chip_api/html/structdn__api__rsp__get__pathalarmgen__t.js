var structdn__api__rsp__get__pathalarmgen__t =
[
    [ "rc", "structdn__api__rsp__get__pathalarmgen__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__pathalarmgen__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "isGenerate", "structdn__api__rsp__get__pathalarmgen__t.html#a9fd8a1d4537b53ad49fd196da6a745c8", null ]
];