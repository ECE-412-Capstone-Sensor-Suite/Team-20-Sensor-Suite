var structdn__api__rsp__get__apstatus__t =
[
    [ "rc", "structdn__api__rsp__get__apstatus__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__apstatus__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "state", "structdn__api__rsp__get__apstatus__t.html#a098b904cc4606bc5d8dd934d4803a979", null ],
    [ "clkSrc", "structdn__api__rsp__get__apstatus__t.html#a6fe266cbc634a7d79721f5dfab378d43", null ]
];