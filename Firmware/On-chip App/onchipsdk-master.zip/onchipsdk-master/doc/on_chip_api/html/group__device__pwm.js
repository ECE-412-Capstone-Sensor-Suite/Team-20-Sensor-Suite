var group__device__pwm =
[
    [ "dn_pwm_open_args_t", "structdn__pwm__open__args__t.html", [
      [ "period", "structdn__pwm__open__args__t.html#a9eeb54a6ab38655557afcb5af022d1a2", null ],
      [ "duty_cycle", "structdn__pwm__open__args__t.html#a601abfe27e3ea43d881a9aa4f0724963", null ]
    ] ],
    [ "dn_pwm_ioctl_set_t", "structdn__pwm__ioctl__set__t.html", [
      [ "duty_cycle", "structdn__pwm__ioctl__set__t.html#a601abfe27e3ea43d881a9aa4f0724963", null ]
    ] ],
    [ "DN_IOCTL_PWM_ENABLE", "group__device__pwm.html#ga23b0dac6a285705c589547796977a289", null ],
    [ "DN_IOCTL_PWM_DISABLE", "group__device__pwm.html#gad5ba5abc59699fcb5b38c62dd8c006b3", null ],
    [ "DN_IOCTL_PWM_SET", "group__device__pwm.html#ga9450504cc7f46f98d317cd76d4fa21ef", null ],
    [ "DN_PWM_139US", "group__device__pwm.html#ga9ee993c9dce24e429d1998e1b1b722c1", null ],
    [ "DN_PWM_556US", "group__device__pwm.html#ga22abb8240b476c0f08162075db780c55", null ],
    [ "DN_PWM_2P2MS", "group__device__pwm.html#ga5bf9d3b8fcf298c67f90a8fa774a0b7e", null ],
    [ "DN_PWM_4P4MS", "group__device__pwm.html#gae008a26be456ad1d57eecf26dae231ae", null ],
    [ "DN_PWM_8P9MS", "group__device__pwm.html#gab518a8a15143c09bc12c800bde06e350", null ],
    [ "DN_PWM_17P8MS", "group__device__pwm.html#ga7d647bd73862875ed1410b88fa9ccf1c", null ],
    [ "DN_PWM_35P5MS", "group__device__pwm.html#gadb79f02e165e81bc1f8144780f5d9eeb", null ],
    [ "DN_PWM_71P1MS", "group__device__pwm.html#ga8e507db0d3fc860ad7130d1dbf064ebe", null ],
    [ "DN_PWM_142MS", "group__device__pwm.html#ga42979a1cfe3d951602d624c49e336cf9", null ],
    [ "DN_PWM_569MS", "group__device__pwm.html#ga69c4aba71efb58c425611699826dac29", null ],
    [ "DN_PWM_1P138S", "group__device__pwm.html#gad3ab8a7bb854d371ba9546a1255138a5", null ]
];