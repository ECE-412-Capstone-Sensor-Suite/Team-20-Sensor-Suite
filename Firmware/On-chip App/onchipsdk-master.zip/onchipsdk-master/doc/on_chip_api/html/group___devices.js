var group___devices =
[
    [ "Device API", "group__device__api.html", "group__device__api" ],
    [ "Sensors", "group__device__sensors.html", "group__device__sensors" ],
    [ "Other", "group__device__other.html", "group__device__other" ]
];