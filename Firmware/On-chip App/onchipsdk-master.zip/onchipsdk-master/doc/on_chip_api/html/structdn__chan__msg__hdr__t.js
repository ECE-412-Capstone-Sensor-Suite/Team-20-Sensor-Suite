var structdn__chan__msg__hdr__t =
[
    [ "msgType", "structdn__chan__msg__hdr__t.html#a68a8c7e254c9b6e5e45ba3d683efeee4", null ],
    [ "len", "structdn__chan__msg__hdr__t.html#af920c89db6b0d15d874a78bf5fce9a4b", null ]
];