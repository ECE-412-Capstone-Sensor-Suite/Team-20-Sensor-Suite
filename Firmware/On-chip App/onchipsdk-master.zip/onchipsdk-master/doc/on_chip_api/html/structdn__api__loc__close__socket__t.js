var structdn__api__loc__close__socket__t =
[
    [ "socketId", "structdn__api__loc__close__socket__t.html#a13a24911b35c9f0cf779764a55faabc9", null ]
];