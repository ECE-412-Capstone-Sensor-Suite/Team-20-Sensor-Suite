var structdn__api__loc__bind__socket__t =
[
    [ "socketId", "structdn__api__loc__bind__socket__t.html#a13a24911b35c9f0cf779764a55faabc9", null ],
    [ "port", "structdn__api__loc__bind__socket__t.html#afbb6b3545f891423a28757d914e53aad", null ]
];