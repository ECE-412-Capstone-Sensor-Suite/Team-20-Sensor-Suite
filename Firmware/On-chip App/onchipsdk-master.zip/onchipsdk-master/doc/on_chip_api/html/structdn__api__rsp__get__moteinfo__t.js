var structdn__api__rsp__get__moteinfo__t =
[
    [ "rc", "structdn__api__rsp__get__moteinfo__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__moteinfo__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "apiVersion", "structdn__api__rsp__get__moteinfo__t.html#acd31344bd4e9dc32704255df66c132d4", null ],
    [ "serialNumber", "structdn__api__rsp__get__moteinfo__t.html#a78a294d49771275a767ae8888486c6b5", null ],
    [ "hwModel", "structdn__api__rsp__get__moteinfo__t.html#a2154409cdc369422dd574835ed284bfd", null ],
    [ "hwRev", "structdn__api__rsp__get__moteinfo__t.html#af5a7e9e94f8b94406a4c7db50327938a", null ],
    [ "swVer", "structdn__api__rsp__get__moteinfo__t.html#aaab308f9f121ac2e477f065457acc54a", null ],
    [ "blSwVer", "structdn__api__rsp__get__moteinfo__t.html#a1f0cfc7ced9e20bea75e417ce526452e", null ]
];