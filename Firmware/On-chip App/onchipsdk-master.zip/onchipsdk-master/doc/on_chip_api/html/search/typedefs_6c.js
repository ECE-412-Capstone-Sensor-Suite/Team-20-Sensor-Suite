var searchData=
[
  ['locnotifcb_5ft',['locNotifCb_t',['../group__module__dnm__local.html#ga49037545e95c60c6ceeb7d87ee8d9e50',1,'dnm_local.h']]]
];
