var searchData=
[
  ['writebuf',['writeBuf',['../structdn__ioctl__i2c__transfer__t.html#a875fd163836a0503b30905633da2d853',1,'dn_ioctl_i2c_transfer_t']]],
  ['writedata',['writeData',['../structdn__ow__ioctl__writebit__t.html#ae61bd828090a5da6bd3342318148d437',1,'dn_ow_ioctl_writebit_t']]],
  ['writelen',['writeLen',['../structdn__ioctl__i2c__transfer__t.html#a866c50647056667861d79b8cbb93d3fe',1,'dn_ioctl_i2c_transfer_t']]]
];
