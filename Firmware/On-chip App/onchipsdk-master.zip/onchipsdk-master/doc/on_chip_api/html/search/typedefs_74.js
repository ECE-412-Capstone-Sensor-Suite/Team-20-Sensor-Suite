var searchData=
[
  ['timenotifcb_5ft',['timeNotifCb_t',['../group__module__dnm__local.html#gaa252b66ffd1c32af5b77015e6ab66402',1,'dnm_local.h']]],
  ['txdonenotifcb_5ft',['txDoneNotifCb_t',['../group__module__dnm__local.html#ga55fe3c4bad237d0a08ebd367a4394456',1,'dnm_local.h']]]
];
