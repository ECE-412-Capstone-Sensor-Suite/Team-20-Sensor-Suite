var structdn__api__rsp__get__ip6addr__t =
[
    [ "rc", "structdn__api__rsp__get__ip6addr__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__ip6addr__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "ipAddr", "structdn__api__rsp__get__ip6addr__t.html#a8454396129471058db4293c3475b1601", null ]
];