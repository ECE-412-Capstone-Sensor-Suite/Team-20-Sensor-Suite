var structdn__api__set__txpower__t =
[
    [ "paramId", "structdn__api__set__txpower__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "txPower", "structdn__api__set__txpower__t.html#a5e7690930c317784b88fec23076c06ba", null ]
];