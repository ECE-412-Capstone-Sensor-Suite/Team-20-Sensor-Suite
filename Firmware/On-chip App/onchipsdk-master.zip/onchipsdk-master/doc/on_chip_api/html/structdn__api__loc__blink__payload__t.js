var structdn__api__loc__blink__payload__t =
[
    [ "fIncludeDscvNbrs", "structdn__api__loc__blink__payload__t.html#a5a2d47322189cc35f8e6ce851b65041c", null ],
    [ "payload", "structdn__api__loc__blink__payload__t.html#ad5215ed66763dfdd9a6ef010aa2def37", null ]
];