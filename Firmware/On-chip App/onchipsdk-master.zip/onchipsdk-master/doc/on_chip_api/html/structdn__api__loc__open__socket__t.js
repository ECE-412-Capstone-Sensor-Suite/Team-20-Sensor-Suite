var structdn__api__loc__open__socket__t =
[
    [ "protocol", "structdn__api__loc__open__socket__t.html#add2ec924c0f221790d7235ffb2e615cd", null ]
];