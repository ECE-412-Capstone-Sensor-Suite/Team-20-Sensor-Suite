var structdn__api__loc__write__gps__status__t =
[
    [ "status", "structdn__api__loc__write__gps__status__t.html#a85488c9ff4e6d37baf45a5e743d7fa2b", null ]
];