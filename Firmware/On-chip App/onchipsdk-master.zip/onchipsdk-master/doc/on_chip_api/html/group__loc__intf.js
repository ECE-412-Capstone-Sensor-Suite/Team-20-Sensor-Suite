var group__loc__intf =
[
    [ "Common", "group__loc__intf__common.html", "group__loc__intf__common" ],
    [ "Request/response formats", "group__loc__intf__reqresp__formats.html", "group__loc__intf__reqresp__formats" ],
    [ "Notification formats", "group__loc__intf__notif__formats.html", "group__loc__intf__notif__formats" ],
    [ "setParam/getParam formats", "group__loc__intf__setgetparam__formats.html", "group__loc__intf__setgetparam__formats" ],
    [ "DN_API_LOC_MAXMSG_SIZE", "group__loc__intf.html#gad3622894e55512ee7bd267dad59d12fb", null ],
    [ "DN_API_LOC_MAX_REQ_SIZE", "group__loc__intf.html#gaed46f2c20356b45cc159198803a1f366", null ],
    [ "DN_API_LOC_MAX_RESP_SIZE", "group__loc__intf.html#ga91726706ed383ce7a16002d688dc0666", null ],
    [ "DN_API_LOC_MAX_NOTIF_SIZE", "group__loc__intf.html#ga58e88973a261941832977748aef9a0a3", null ],
    [ "DN_API_LOC_MAX_USERPAYL_SIZE", "group__loc__intf.html#gab5e34ca936de9177f2c7dcc5fb1cbb52", null ]
];