var structdn__api__loc__notif__txdone__t =
[
    [ "packetId", "structdn__api__loc__notif__txdone__t.html#a3609b8fabc95f20578b60c3205d4e215", null ],
    [ "status", "structdn__api__loc__notif__txdone__t.html#a015eb90e0de9f16e87bd149d4b9ce959", null ]
];