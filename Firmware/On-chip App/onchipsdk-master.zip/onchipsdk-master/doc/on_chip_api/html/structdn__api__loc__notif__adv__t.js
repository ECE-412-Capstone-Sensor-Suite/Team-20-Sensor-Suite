var structdn__api__loc__notif__adv__t =
[
    [ "netId", "structdn__api__loc__notif__adv__t.html#a7859e131bbd006f6dc6c0d9e6e90a7b9", null ],
    [ "moteId", "structdn__api__loc__notif__adv__t.html#ae715676c67943e87ae9b7b13bf5d556e", null ],
    [ "rssi", "structdn__api__loc__notif__adv__t.html#aa6bf3d63b3a7e6972770f4a7674ee72b", null ],
    [ "joinPri", "structdn__api__loc__notif__adv__t.html#ac03034b9315729f22ca254e8ae66a9f3", null ]
];