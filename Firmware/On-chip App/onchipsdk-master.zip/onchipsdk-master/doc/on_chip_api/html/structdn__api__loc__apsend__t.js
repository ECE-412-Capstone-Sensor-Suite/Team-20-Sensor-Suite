var structdn__api__loc__apsend__t =
[
    [ "control", "structdn__api__loc__apsend__t.html#a8c2c98d5c6394bb120b8740b01b57eaf", null ],
    [ "payload", "structdn__api__loc__apsend__t.html#a322ec651b6cdaaefe4b9baf6bab765fe", null ]
];