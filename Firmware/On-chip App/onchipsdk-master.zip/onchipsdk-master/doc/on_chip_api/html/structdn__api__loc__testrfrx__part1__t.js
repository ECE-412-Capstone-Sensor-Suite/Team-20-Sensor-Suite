var structdn__api__loc__testrfrx__part1__t =
[
    [ "mask", "structdn__api__loc__testrfrx__part1__t.html#aa9bc93d0984bcb4d0562871ba7bbba78", null ],
    [ "timeSeconds", "structdn__api__loc__testrfrx__part1__t.html#a7aab0ac3851f26e5783de6a5961267ac", null ]
];