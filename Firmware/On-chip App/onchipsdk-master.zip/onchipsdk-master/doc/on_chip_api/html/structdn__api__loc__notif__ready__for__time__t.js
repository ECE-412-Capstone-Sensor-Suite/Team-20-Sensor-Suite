var structdn__api__loc__notif__ready__for__time__t =
[
    [ "seqNum", "structdn__api__loc__notif__ready__for__time__t.html#ac946a1bca79e072cec9bc01cb0c827c2", null ]
];