var structdn__api__rsp__get__advgraph__t =
[
    [ "rc", "structdn__api__rsp__get__advgraph__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__advgraph__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "advGraph", "structdn__api__rsp__get__advgraph__t.html#abfc75386112ee6c2836d1b33b1273f7e", null ]
];