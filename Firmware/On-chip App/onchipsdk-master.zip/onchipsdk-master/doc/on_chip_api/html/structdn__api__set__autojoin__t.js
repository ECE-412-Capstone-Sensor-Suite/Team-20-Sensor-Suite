var structdn__api__set__autojoin__t =
[
    [ "paramId", "structdn__api__set__autojoin__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "mode", "structdn__api__set__autojoin__t.html#a6f850a24512f7d3dbabb1345cf61cc6f", null ]
];