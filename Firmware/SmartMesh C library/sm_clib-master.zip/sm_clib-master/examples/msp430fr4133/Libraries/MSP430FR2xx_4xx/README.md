These MSP430FR2xx_4xx libraries are used untouched from the "MSP-EXP430FR4133 Software for Windows" available on ti.com.

Please see the license applicable to the MSP430FR2xx_4xx libraries directly in each of the source code files.