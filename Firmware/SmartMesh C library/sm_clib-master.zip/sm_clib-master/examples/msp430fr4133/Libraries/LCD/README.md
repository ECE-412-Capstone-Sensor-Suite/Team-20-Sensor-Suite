These LCD libraries for the MSP430RF4133 LaunchPad LCD libraries were adapted from the "MSP-EXP430FR4133 Software for Windows" available on ti.com.

Please see the license applicable to the MSP430RF4133 LaunchPad LCD libraries directly in each of the source code files.