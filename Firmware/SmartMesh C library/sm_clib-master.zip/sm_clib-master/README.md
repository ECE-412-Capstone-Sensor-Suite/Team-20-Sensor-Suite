C Library
=========

Dust SmartMeshSDK C Library

* [Documentation](https://dustcloud.atlassian.net/wiki/display/CLIB)
* [Discussion](https://dustcloud.atlassian.net/wiki/questions)
* [Issue tracking](https://dustcloud.atlassian.net/browse/CLIB)
